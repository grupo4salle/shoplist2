package myaplication.android.dani.shop_list.Adapters;

import android.app.Activity;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;

import java.util.ArrayList;

import myaplication.android.dani.shop_list.Model.ItemList;
import myaplication.android.dani.shop_list.R;


/**
 * Created by Dani on 20/12/2017.
 */


public class Adapter extends RecyclerView.Adapter<Holder>{

    private ArrayList<ItemList> items;
    private  Activity activity;

    public Adapter(ArrayList<ItemList> items, Activity activity){
        this.items = items;
        this.activity = activity;
    }

    @Override
    public Holder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = activity.getLayoutInflater().inflate(R.layout.holder,parent,false);
        Holder holder = new Holder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(Holder holder, int position) { // con el item creado le ponemos valores a los diferentes textview
        ItemList item = items.get(position);
        holder.textViewName.setText(item.getName());
        holder.textViewCount.setText(String.valueOf(item.getCantidad()));

    }

    @Override
    public int getItemCount() { // cuantos items va a tener que representar
        return items.size();
    }
}

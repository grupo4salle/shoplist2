package myaplication.android.dani.shop_list.Controller;

import java.util.ArrayList;

import myaplication.android.dani.shop_list.Model.ItemList;

/**
 * Created by Dani on 20/12/2017.
 */

public class MainAxtivityManager {
    private ArrayList<ItemList> itemLists;

    public MainAxtivityManager() {
        this.itemLists = new ArrayList<>();
        itemLists.add(new ItemList("Arroz", 2));
        itemLists.add(new ItemList("Pan", 1));
    }

    public ArrayList<ItemList> getItemLists() {
        return itemLists;
    }

    public void setItemLists(ArrayList<ItemList> itemLists) {
        this.itemLists = itemLists;
    }
}

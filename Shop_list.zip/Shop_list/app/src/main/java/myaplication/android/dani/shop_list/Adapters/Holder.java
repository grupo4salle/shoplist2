package myaplication.android.dani.shop_list.Adapters;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;
import myaplication.android.dani.shop_list.R;


/**
 * Created by Dani on 20/12/2017.
 */

public class Holder extends RecyclerView.ViewHolder {
    TextView textViewName;
    TextView textViewCount;

    public Holder(View itemView) {
        super(itemView);

        textViewName = itemView.findViewById(R.id.textView2);
        textViewCount = itemView.findViewById(R.id.textView);

    }
}

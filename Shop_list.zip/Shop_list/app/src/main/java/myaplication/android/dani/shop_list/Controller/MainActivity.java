package myaplication.android.dani.shop_list.Controller;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.CheckBox;


import myaplication.android.dani.shop_list.Adapters.Adapter;
import myaplication.android.dani.shop_list.R;

public class MainActivity extends AppCompatActivity {

    private MainAxtivityManager manager;

    private RecyclerView recyclerView;
    private CheckBox addButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        manager = new MainAxtivityManager();
        recyclerView = (RecyclerView)findViewById(R.id.recyclerView);

        Adapter adapter = new Adapter(manager.getItemLists(),this);
        recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        recyclerView.setAdapter(adapter);


    }
}
